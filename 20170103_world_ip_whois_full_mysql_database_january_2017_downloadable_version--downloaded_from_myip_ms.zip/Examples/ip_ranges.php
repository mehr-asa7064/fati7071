<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IP Ranges Whois Database, 2017 year - downloadable version</title>

    <!-- Latest JQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
	
	<!-- Optional theme
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">
	 -->

	<!-- Latest compiled and minified JavaScript -->
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

	<!-- Custom styles for this template -->
	<link href="style.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	
	<!-- Data Tables -->
	<link href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"> 
	<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js" type="text/javascript"></script>
	<script src="//cdn.datatables.net/plug-ins/1.10.7/sorting/ip-address.js" type="text/javascript"></script>
	<script>
		$(document).ready(function() {
		    var t = $('#ipranges-table').DataTable({
				paging: true,
				"pageLength": 50,  
				"bAutoWidth": false,
		        "columnDefs": [ {
		            "searchable": false,
		            "orderable": false,
		            "targets": 0
		        } ],
				"columns": [
				            { "width": "5%" },
				            { type: "ip-address", "width": "23%" },
				            { "width": "24%" },
				            { "width": "16%" },
				            { "width": "21%" },
				            { "bSearchable": false , "orderable": false }
				           ],
		        "order": [[ 1, 'asc' ]]
		    });
		 
		    t.on( 'order.dt search.dt', function () {
		        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
		            cell.innerHTML = i+1;
		        } );
		    } ).draw();
		});
	</script>

	
  </head>

  
  
  
  
  
  
  
  <body>

    <div class="container">

      <div class="masthead">
        <h3 class="text-muted">PHP Example - Myip.ms Whois Database, 2017 year (<a href='http://myip.ms/info/whois_database_download/'>download</a>)</h3>
        <nav>
          <ul class="nav nav-justified">
            <li><a href="index.php">Home</a></li>
            <li class="active"><a href="ip_ranges.php">IPv4 Ranges</a></li>
            <li><a href="ip6_ranges.php">IPv6 Ranges</a></li>
            <li><a href="ip_owners.php">IP Owners</a></li>
            <li><a href="http://myip.ms/info/whois_database_download/">Download</a></li>
          </ul>
        </nav>	
      </div>

      <div class="jumbotron">
        <h1>IP Ranges - Demo</h1>
        <p class="lead"><a href='http://myip.ms/info/whois_database_download/'>Full database</a> have more than <a href='http://myip.ms/browse/ip_ranges/IP_Ranges_by_Owner'>575,000+ records</a> of IPv4 ranges<br>
      </div>
       
      <div class="row normal">
        <div class="col-lg-12">

			 <table id='ipranges-table' class="table table-striped">
			 	<thead>
			 		<tr><th></th><th data-class-name="priority">IP Range</th><th>Owner</th><th>Country</th><th>Reslove Host</th><th>Website</th><th></th></tr>
			 	</thead>	
			 	
			 	 <tbody>
				 	<?php
			
				 	include_once("db.php");
				 	
				 	$sql = "select ip_ranges.rangeID,
    						concat_ws(' - ', inet_ntoa(ip_ranges.ipID), inet_ntoa(ip_ranges.ip2ID)) as ip_range,
    						ip_owners.ownerID,  
    						ip_owners.ownerName, 
    						countries.countryID, 
    						countries.countryName, 
    						ip_ranges.host,
    						ip_ranges.whois
    						from ip_ranges
    						left join ip_owners using (ownerID)
    						left join countries using (countryID)
    						limit 1000";

				 	$arr = run_sql($sql, true);
				 	
				 	foreach ($arr as $row)
				 	{
				 		$rawID = "rawModal".$row->rangeID;
				 		echo "<tr><td></td><td>".$row->ip_range."</td><td><a target='_blank' href='http://myip.ms/view/ip_owners/".$row->ownerID."'>".$row->ownerName."</a></td><td><img src='images/flags/".$row->countryID.".png'>".$row->countryName."</td><td class='cuttext'>".$row->host."</td>\n";
				 		?>
				 		
			 			<td align="center"><button type="button" class="btn btn-success" data-toggle="modal" data-target="#<?=$rawID ?>">Raw Whois</button>
						<!-- Modal -->
						<div class="modal fade" id="<?=$rawID ?>" tabindex="-1" role="dialog" aria-labelledby="<?=$rawID ?>Label" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content" align="left">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						        <h4 class="modal-title" id="<?=$rawID ?>Label">Range Whois: &#160; <?=$row->ip_range ?></h4>
						      </div>
						      <div class="modal-body">
						        	<?=nl2br($row->whois) ?>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
						      </div>
						    </div>
						  </div>
						</div>
					</td></tr>	
						
			 		<?php }  ?>
			 		
		 	    </tbody>
			</table>
        
        </div>
      </div>
      

      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; Company</p>
      </footer>

    </div>


  </body>
</html>
