<?

	define('DB_NAME', ''); 					/** The name of the database */
	define('DB_USER', '');					/** MySQL database username */
	define('DB_PASSWORD', ''); 				/** MySQL database password */
	define('DB_HOST', 'localhost');				/** MySQL hostname */


	
	
	
	
	/** Don't change below **/

	function run_sql($sql, $array_result = false)
	{
		static $mysqli;
	
		$f = true;
		$g = $x = false;
		$res = array();
	
		if (!$mysqli)
		{
			$dbhost = DB_HOST;
			$port = NULL; $socket = NULL; 
			if (strpos(DB_HOST, ":"))
			{ 
				list($dbhost, $port) = explode(':', DB_HOST);
				if (is_numeric($port)) $port = (int) $port;
				else
				{
					$socket = $port;
					$port = NULL;
				}
			}
			$mysqli = @mysqli_connect($dbhost, DB_USER, DB_PASSWORD, DB_NAME, $port, $socket);			
			if (mysqli_connect_errno())
			{
				echo "<br /><b>Error. Can't connect to your MySQL server.</b> You need to have PHP 5.2+ and MySQL 5.5+ with mysqli extension activated. <a href='http://crybit.com/how-to-enable-mysqli-extension-on-web-server/'>Instruction &#187;</a>\n";
				echo "<br />Also <b>please check DB username/password in file cryptobox.config.php</b>\n";
				echo "<br />Server has returned error - <b>".mysqli_connect_error()."</b>\n";
				die();
			}
			$mysqli->query("SET NAMES utf8");
		}
	
		$query = $mysqli->query($sql);
	
		if ($query === FALSE) die("<br><hr><font color='red'><b>MySQL Error: ".$mysqli->error.".</b></font><br><b>SQL:</b> $sql<br><hr><br>");
		elseif (is_object($query) && $query->num_rows)
		{
			while($row = $query->fetch_object())
			{
				if ($f)
				{
					if (property_exists($row, "idx")) $x = true;
					$c = count(get_object_vars($row));
					if ($c > 2 || ($c == 2 && !$x)) $g = true;
					elseif (!property_exists($row, "nme")) die("Error in run_sql() - 'nme' not exists! SQL: $sql");
					$f = false;
				}
	
				if (!$g && $query->num_rows == 1 && property_exists($row, "nme")) return $row->nme;
				elseif ($x) $res[$row->idx] = ($g) ? $row : $row->nme;
				else $res[] = ($g) ? $row : $row->nme;
			}
		}
		elseif (stripos($sql, "insert ") !== false) $res = $mysqli->insert_id;

		if (is_object($query)) $query->close();
		if (!$array_result && is_array($res) && count($res) == 1 && isset($res[0]) && is_object($res[0])) $res = $res[0];

		return $res;
	}

?>