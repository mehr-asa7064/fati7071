<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Myip.ms Whois Database, 2017 year - downloadable version</title>

	<!-- Latest JQuery -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	    
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
	
	<!-- Optional theme
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">
	 -->
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
	
	<!-- Custom styles for this template -->
	<link href="style.css" rel="stylesheet">
	
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<!-- Google recaptcha -->
	<script src='https://www.google.com/recaptcha/api.js'></script>
	
  </head>


  <?php 

  //if POST 
  $qaddr = $ip = $error = "";
  if (isset($_POST["qaddr"]) && $_POST["qaddr"])
  {
  	$qaddr = trim($_POST["qaddr"], " /");
  	$qaddr = str_ireplace(array("http://", "https://", "ftp://"), array("", "", ""), $qaddr);
  	if (strpos($qaddr, "/")) $qaddr = substr($qaddr, 0, strpos($qaddr, "/"));
  	$qaddr = preg_replace('/[^a-zA-Z0-9\:\.\-\_]/', '', $qaddr);
  	if (filter_var($qaddr, FILTER_VALIDATE_IP)) {
  		$ip = $qaddr;
  	}
  	else {
  		$ip = gethostbyname($qaddr);
  		if (!filter_var($ip, FILTER_VALIDATE_IP)) $error = "Invalid IP Address / Website Name";
  	}
  	
  	// captcha
  	/*
  	if (!$error)
  	{
  		$captcha = trim($_POST['g-recaptcha-response']);
  		if (!$captcha) $error = "Please check the captcha form";
  		else {
			$captha_sec_key = "-- Enter Your Google Captcha Key ---";
			$response=json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$captha_sec_key."&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']), true);
			if($response['success'] == false) $error = "Invalid captcha. Please check the captcha form";
		}
  	}
  	*/
  }
  
  ?>
  
  
  <body>

    <div class="container">

      <div class="masthead">
        <h3 class="text-muted">PHP Example - Myip.ms Whois Database, 2017 year (<a href='http://myip.ms/info/whois_database_download/'>download</a>)</h3>
        <nav>
          <ul class="nav nav-justified">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="ip_ranges.php">IPv4 Ranges</a></li>
            <li><a href="ip6_ranges.php">IPv6 Ranges</a></li>
            <li><a href="ip_owners.php">IP Owners</a></li>
            <li><a href="http://myip.ms/info/whois_database_download/">Download</a></li>
          </ul>
        </nav>	
      </div>

      
      <div class="jumbotron">
        <h1>Whois Database</h1>
        <p class="lead">Myip.ms <a href='http://myip.ms/info/whois_database_download/'>Full Whois Database</a> in Mysql Format for use in your applications.<br>
        More than 240,000+ records of IP range Owners. More than 575,000+ records of IPv4 ranges<br>
        It covers virtually all existing IPv4 addresses (4,294,967,296 ip)</p>
        <p class="lead">DB version (downloadable version, ~500 Mb database)</p>
        <p class="lead"><a href='http://myip.ms/download/reports/16/previewName/whois_database_demo.zip'>Download Free Database</a> &#160;or&#160; <a href='http://myip.ms/info/whois_database_download/#buy'>Buy Full Version</a> &#160; <small>(Try Live Demo below)</small></p>
        </div>
       
       
       <div style='margin-bottom:40px' class="row">
       <form role="form" method="post" action="index.php">
        <div class="col-lg-2"></div>
       <div class="col-lg-7">
			<div class="form-group">
			<input class="form-control input-lg" id="qaddr" name="qaddr" value="<?=$qaddr ?>" type="text" placeholder="Enter IP Address or Website Name (64.18.50.5, 2a02:598::1, yahoo.com)" >
			<?php if ($error) echo "<br><div class='alert alert-danger' role='alert'>".$error."</div>"; ?> 
	<!--	<br>
			<div align="center" class="g-recaptcha" data-sitekey="--enter-your-key--"></div> -->
 			</div>
       </div>
       	<div class="col-lg-3">
			<button class="btn btn-lg btn-success" type="submit">Get Whois</button>       	
		</div>
		</form>	
      </div>
	  

	  
      <?php 
      	if ($ip && !$error) 
		{ 

			include_once("db.php");
			
			if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6))
				$sql = "select concat_ws(' - ', inet6_ntoa(ip_ranges6.ip6ID), inet6_ntoa(ip_ranges6.ip62ID)) as ip_range,
	    				ip_owners.ownerID,
						ip_owners.ownerName,
						ip_owners.provider,
						ip_owners.address,
						countries.countryID,
	    				countries.countryName,
						ip_owners.phone,
						ip_owners.website,
    					ip_ranges6.cidr,
						ip_ranges6.whois
						from ip_ranges6
						left join ip_owners using (ownerID)
						left join countries using (countryID)
						where inet6_aton('".$ip."') between ip6ID and ip62ID && ownerID != 2 
						order by ip6ID desc";
			
			else
				$sql = "select concat_ws(' - ', inet_ntoa(ip_ranges.ipID), inet_ntoa(ip_ranges.ip2ID)) as ip_range,
	    				ip_owners.ownerID,  
						ip_owners.ownerName, 
						ip_owners.provider, 
						ip_owners.address, 
						countries.countryID, 
	    				countries.countryName, 
						ip_owners.phone,
						ip_owners.website,
						ip_ranges.cidr,
						ip_ranges.whois
						from ip_ranges
						left join ip_owners using (ownerID)
						left join countries using (countryID)
						where inet_aton('".$ip."') between ipID and ip2ID
						order by ipID desc";
			
			$arr = run_sql($sql, true);

      	?>
      
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-11">

	        <?php 
	        
	        if (!$arr)
	        {
	        	echo "<div class='alert alert-warning' role='alert'>No Whois Data found for IP Address - ".$ip.($ip!=$qaddr?" &#160;(".$qaddr.")":"")."</div>";
	        }
	        else
	        {
	        	 
        		echo "<h2>Whois Results - Found &#160;<span class='label label-default'>".count($arr)." ip address owner".(count($arr)>1?"s":"")."</span></h2><br>";
        		echo "<big><div class='alert alert-success' role='alert'>Query: <b>".$qaddr."</b> ".($ip!=$qaddr?" &#160;(".$ip.")":"")."</div>";
        		echo "<div class='panel panel-default'>
					  	<div class='panel-heading'>Summary</div>
					 	<table id='ipranges-table' class='table table-striped'>
					 		<thead>
			 					<tr><th width='5%'></th><th width='27%'>IP Range</th><th width='30%'>Owner</th><th width='16%'>Country</th><th>Website</th></tr>
			 				</thead>
			 	 			<tbody>";
        		
			        		foreach ($arr as $k=>$row)
			        		{
			        			if (!$row->countryID) $row->countryID = "empty";
			        			echo "<tr><td>".($k+1).".</td><td><a href='#w".($k+1)."'>".$row->ip_range."</a></td><td><a target='_blank' href='http://myip.ms/view/ip_owners/".$row->ownerID."'>".$row->ownerName."</a></td><td><img src='images/flags/".$row->countryID.".png'>".$row->countryName."</td><td class='cuttext'>".$row->website."</td>\n";
			        		}
        		
			 	 echo 	  "</tbody>
					 	</table>
					</div>
  					</big><br><br>
			 	 </div>
		</div>";
			 	 
			 	 
	echo "<div class='row'>
	 	 	<div class='col-lg-1'></div>
	 	 	<div class='col-lg-10'>";
	 	 
	 	 
	 	 	foreach ($arr as $k=>$row)
	 	 	{
	 	 		if (!$row->countryID) $row->countryID = "empty";
	 	 		
	 	 		echo "<a id='w".($k+1)."'></a>";
	 	 		echo "<h3>".($k+1).". ".($k>0?"Parent ":"")."Owner</h3><br>";
	 	 			
	 	 		echo "<table class='table table-striped'><tbody>";
	 	 		echo "<tr><td width='150'>IP Range</td><td>".$row->ip_range."</td></tr>";
	 	 		echo "<tr><td>Owner</td><td><b>".$row->ownerName."</b></td></tr>";
	 	 		if ($row->provider) 	echo "<tr><td>Provider</td><td>".$row->provider."</td></tr>";
	 	 		if ($row->address) 		echo "<tr><td>Address</td><td>".$row->address."</td></tr>";
	 	 		if ($row->countryName) 	echo "<tr><td>Country</td><td><img src='images/flags/".$row->countryID.".png'> ".$row->countryName."</td></tr>";
	 	 		if ($row->phone) 		echo "<tr><td>Phone</td><td>".$row->phone."</td></tr>";
	 	 		if ($row->website) 		echo "<tr><td>Website</td><td>".$row->website."</td></tr>";
	 	 		if ($row->cidr) 		echo "<tr><td>CIDR</td><td>".$row->cidr."</td></tr>";
	 	 		if ($row->whois) 		echo "<tr><td>Whois</td><td colspan='2'>".nl2br($row->whois)."</td></tr>";
	 	 		echo "</tbody></table><br><br>";
	 	 	}
		}
		 
		?>
			
		</div>
		<div class="col-lg-1"></div>
	</div>
				
	<?php } ?>
      
      
	  
	  
	  
      <div style="padding-top:130px" class="row">
        <div class="col-lg-4">
          <h2>IPv4 Ranges</h2>
          <br>
          <p>More than 575,000+ records of IPv4 ranges</p>
          <br>
          <p><a class="btn btn-primary" href="ip_ranges.php" role="button">View details &raquo;</a></p>
          <br><br>
       </div>
       <div class="col-lg-4">
          <h2>IPv6 Ranges</h2>
          <br>
          <p>More than 13,000+ records of IPv6 ranges</p>
          <br>
          <p><a class="btn btn-primary" href="ip6_ranges.php" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-lg-4">
          <h2>IP Owners</h2>
          <br>
          <p>More than 240,000+ records of IP Range Owners</p>
          <br>
          <p><a class="btn btn-primary" href="ip_owners.php" role="button">View details &raquo;</a></p>
        </div>
      </div>

      <!-- Site footer -->
      <footer class="footer">
        <p>&copy; Company</p>
      </footer>

    </div>


  </body>
</html>
